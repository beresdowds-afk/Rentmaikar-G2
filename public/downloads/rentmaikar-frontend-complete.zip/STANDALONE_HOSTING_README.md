# RentMaikar Standalone Frontend

This archive contains all the frontend source files for RentMaikar, configured to run standalone on `rentmaikar.com` and seamlessly communicate with the backend at `staging.rentmaikar.com`.

## Quick Start

1. Install dependencies:
   ```bash
   npm install
   ```

2. Development server:
   ```bash
   npm run dev
   ```

3. Production Build:
   ```bash
   npm run build
   ```
   The compiled static files will be placed in the `dist/` directory.

## Backend Bridge Architecture

The application includes the resilient Backend Bridge (`src/lib/backend-bridge.ts`):
- When hosted on `rentmaikar.com` separately from the backend, it automatically directs API traffic and SSE streams to `https://staging.rentmaikar.com/api`.
- If direct contact is lost, it trips into `STAGING_FALLBACK` mode with zero dropped user mutations, exponential retry backoff, and live event synchronization.

## Hosting on `rentmaikar.com`

You can deploy the built `dist/` folder to any static hosting provider:
- **Cloudflare Pages / Workers**: Set root to `dist/`, redirect all paths to `index.html` (SPA fallback).
- **Vercel / Netlify**: Configure Single Page Application rewrite `/* -> /index.html`.
- **Nginx**: Use the provided `frontend/nginx.conf` or standard `try_files $uri $uri/ /index.html;`.
- **Docker**: Build using `frontend/Dockerfile`.
