import{i as e}from"./rolldown-runtime-aKtaBQYM.js";import{t}from"./react-DA3A6BO2.js";import{t as n}from"./button-D1qd4WMI.js";import{r}from"./utils-DB6Zg50Y.js";import{t as i}from"./bell-qmCpKZN4.js";import{t as a}from"./Footer-CO6sMy0e.js";import{t as o}from"./car-BTCy_sZE.js";import{t as s}from"./check-D5I8_Usn.js";import{t as c}from"./Header-D0cz353w.js";import{t as l}from"./code-COob1kBN.js";import{t as u}from"./copy-DrhRRSgb.js";import{t as d}from"./credit-card-BEGgo2yi.js";import{t as f}from"./database-E--qjQO2.js";import{t as p}from"./globe-DBLXijM4.js";import{t as m}from"./key-Oj1bUbom.js";import{t as h}from"./zap-CcIwUIaP.js";import{Gt as g,Jt as _,Kt as v,d as y,f as b,g as x,h as S,p as C,u as w}from"./index-Bc1IKNAT.js";import{i as T,n as E,r as D,t as O}from"./tabs-NYzgBYwK.js";import{t as k}from"./scroll-area-kjJaj8mr.js";import{i as A,n as j,r as M,t as N}from"./accordion-Bd7PW-Mp.js";var P=e(t(),1),F=r(),I=[{method:`POST`,path:`/functions/v1/send-sms-notification`,description:`Send SMS or WhatsApp notifications to users`,auth:!0,category:`notifications`,requestBody:`{
  "recipientPhone": "+1234567890",
  "notificationType": "payment_reminder",
  "channel": "sms",
  "amount": 150.00,
  "currency": "USD",
  "dueDate": "2024-01-15"
}`,responseBody:`{
  "success": true,
  "messageId": "SM1234567890"
}`,headers:[{name:`Authorization`,value:`Bearer <service_role_key>`,required:!0},{name:`Content-Type`,value:`application/json`,required:!0}]},{method:`POST`,path:`/functions/v1/send-incident-notification`,description:`Send incident alerts to admins, owners, and drivers`,auth:!0,category:`notifications`,requestBody:`{
  "incidentId": "uuid",
  "incidentType": "accident",
  "severity": "high",
  "vehicleId": "uuid",
  "driverId": "uuid",
  "title": "Vehicle Collision Detected",
  "description": "Impact detected at 3.5G force",
  "location": "123 Main St, Lagos"
}`,responseBody:`{
  "success": true,
  "emailsSent": 2,
  "smsSent": 1
}`},{method:`POST`,path:`/functions/v1/send-approval-notification`,description:`Notify users when their account is approved`,auth:!0,category:`notifications`,requestBody:`{
  "email": "user@example.com",
  "name": "John Doe",
  "userType": "driver",
  "region": "USA"
}`,responseBody:`{
  "success": true,
  "emailId": "email_123"
}`},{method:`POST`,path:`/functions/v1/send-price-notification`,description:`Send price negotiation updates via email`,auth:!0,category:`notifications`,requestBody:`{
  "email": "owner@example.com",
  "notificationType": "new_offer",
  "userType": "owner",
  "vehicleName": "Toyota Camry 2022",
  "proposedPrice": 250.00,
  "currentPrice": 300.00,
  "currency": "USD"
}`,responseBody:`{
  "success": true,
  "emailId": "email_456"
}`},{method:`POST`,path:`/functions/v1/iot-accident-detection`,description:`Process IoT sensor data for accident detection`,auth:!0,category:`iot`,requestBody:`{
  "vehicleId": "uuid",
  "deviceId": "DEV-001",
  "triggerType": "collision",
  "decelerationG": 4.5,
  "speedAtImpact": 45.5,
  "location": {
    "lat": 6.5244,
    "lng": 3.3792
  },
  "timestamp": "2024-01-15T10:30:00Z",
  "batteryLevel": 85,
  "signalStrength": -65
}`,responseBody:`{
  "success": true,
  "incidentId": "uuid",
  "severity": "high",
  "notificationsSent": true
}`},{method:`POST`,path:`/functions/v1/verify-phone`,description:`Send or verify phone verification codes`,auth:!0,category:`auth`,requestBody:`{
  "action": "send_code",
  "phone": "+1234567890",
  "channel": "sms"
}`,responseBody:`{
  "success": true,
  "expiresIn": 600
}`},{method:`POST`,path:`/functions/v1/send-order-notification`,description:`Notify admin of new IoT device orders`,auth:!0,category:`orders`,requestBody:`{
  "orderId": "uuid",
  "ownerEmail": "owner@example.com",
  "ownerPhone": "+1234567890",
  "devicePrice": 25000,
  "currency": "NGN",
  "shippingAddress": "123 Lagos Street",
  "paymentMethod": "bank_transfer"
}`,responseBody:`{
  "success": true,
  "emailId": "email_789"
}`},{method:`POST`,path:`/functions/v1/send-shipping-notification`,description:`Notify users when their IoT device ships`,auth:!0,category:`orders`,requestBody:`{
  "email": "owner@example.com",
  "phone": "+1234567890",
  "trackingNumber": "TRK123456789",
  "shippingAddress": "123 Lagos Street"
}`,responseBody:`{
  "success": true,
  "emailSent": true,
  "smsSent": true
}`},{method:`POST`,path:`/functions/v1/process-payment-defaults`,description:`Process and escalate payment defaults (scheduled)`,auth:!0,category:`payments`,requestBody:`{}`,responseBody:`{
  "success": true,
  "processed": 5,
  "notificationsSent": 3,
  "accountsLocked": 1
}`},{method:`POST`,path:`/functions/v1/send-inbox-reply`,description:`Send region-routed SMS/WhatsApp reply via Twilio (US) or Termii (NG)`,auth:!0,category:`communication`,requestBody:`{
  "conversationId": "uuid",
  "messageContent": "Your vehicle is ready for pickup.",
  "channel": "sms",
  "recipientPhone": "+2348012345678"
}`,responseBody:`{
  "success": true,
  "messageSid": "msg_abc123",
  "status": "sent",
  "provider": "termii"
}`,headers:[{name:`Authorization`,value:`Bearer <service_role_key>`,required:!0},{name:`Content-Type`,value:`application/json`,required:!0}]},{method:`POST`,path:`/functions/v1/send-sms-notification`,description:`Region-aware SMS notification — routes to Twilio (US +1) or Termii (NG +234) automatically`,auth:!0,category:`communication`,requestBody:`{
  "recipientPhone": "+2348012345678",
  "notificationType": "payment_reminder",
  "channel": "sms",
  "amount": 50000,
  "currency": "NGN",
  "dueDate": "2026-02-20"
}`,responseBody:`{
  "success": true,
  "messageId": "msg_termii_456",
  "provider": "termii",
  "region": "NG"
}`,headers:[{name:`Authorization`,value:`Bearer <service_role_key>`,required:!0},{name:`Content-Type`,value:`application/json`,required:!0}]},{method:`POST`,path:`/api/webhook/termii/inbound`,description:`Termii inbound webhook — receives incoming SMS from Nigerian numbers, forwards to operational line`,auth:!1,category:`communication`,requestBody:`{
  "sms": {
    "from": "+2348012345678",
    "to": "RENTMAIKAR",
    "message": "I need roadside assistance",
    "type": "plain",
    "channel": "generic"
  }
}`,responseBody:`{
  "success": true,
  "conversationId": "uuid",
  "forwarded": true,
  "forwardedTo": "+234XXXXXXXXXX"
}`},{method:`POST`,path:`/api/webhook/twilio/inbound`,description:`Twilio inbound webhook — receives incoming SMS from US numbers, forwards to operational line`,auth:!1,category:`communication`,requestBody:`{
  "From": "+12025551234",
  "To": "+18005551234",
  "Body": "When is my next payment due?",
  "MessageSid": "SM1234567890"
}`,responseBody:`{
  "success": true,
  "conversationId": "uuid",
  "forwarded": true,
  "forwardedTo": "+1XXXXXXXXXX"
}`}],L=[{id:`all`,label:`All Endpoints`,icon:l},{id:`notifications`,label:`Notifications`,icon:i},{id:`iot`,label:`IoT & Tracking`,icon:o},{id:`auth`,label:`Authentication`,icon:_},{id:`orders`,label:`Orders`,icon:f},{id:`payments`,label:`Payments`,icon:d},{id:`communication`,label:`Communication`,icon:p}],R={GET:`bg-emerald-500/20 text-emerald-400 border-emerald-500/30`,POST:`bg-blue-500/20 text-blue-400 border-blue-500/30`,PUT:`bg-amber-500/20 text-amber-400 border-amber-500/30`,DELETE:`bg-red-500/20 text-red-400 border-red-500/30`,PATCH:`bg-purple-500/20 text-purple-400 border-purple-500/30`},z=({code:e,language:t=`json`})=>{let[r,i]=(0,P.useState)(!1);return(0,F.jsxs)(`div`,{className:`relative group`,children:[(0,F.jsx)(`pre`,{className:`bg-muted/50 border rounded-lg p-4 overflow-x-auto text-sm font-mono`,children:(0,F.jsx)(`code`,{className:`text-foreground/80`,children:e})}),(0,F.jsx)(n,{size:`sm`,variant:`ghost`,className:`absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity`,onClick:()=>{navigator.clipboard.writeText(e),i(!0),g.success(`Copied to clipboard`),setTimeout(()=>i(!1),2e3)},children:r?(0,F.jsx)(s,{className:`h-4 w-4`}):(0,F.jsx)(u,{className:`h-4 w-4`})})]})},B=({endpoint:e})=>(0,F.jsxs)(M,{value:e.path,className:`border rounded-lg mb-3 overflow-hidden`,children:[(0,F.jsx)(A,{className:`px-4 py-3 hover:no-underline hover:bg-muted/30`,children:(0,F.jsxs)(`div`,{className:`flex items-center gap-3 text-left`,children:[(0,F.jsx)(w,{className:`${R[e.method]} font-mono text-xs px-2 py-0.5`,children:e.method}),(0,F.jsx)(`code`,{className:`text-sm font-medium`,children:e.path}),e.auth&&(0,F.jsx)(_,{className:`h-4 w-4 text-muted-foreground`})]})}),(0,F.jsxs)(j,{className:`px-4 pb-4`,children:[(0,F.jsx)(`p`,{className:`text-muted-foreground mb-4`,children:e.description}),e.headers&&(0,F.jsxs)(`div`,{className:`mb-4`,children:[(0,F.jsx)(`h4`,{className:`text-sm font-semibold mb-2`,children:`Headers`}),(0,F.jsx)(`div`,{className:`space-y-1`,children:e.headers.map(e=>(0,F.jsxs)(`div`,{className:`flex items-center gap-2 text-sm`,children:[(0,F.jsx)(`code`,{className:`bg-muted px-2 py-0.5 rounded`,children:e.name}),(0,F.jsx)(`span`,{className:`text-muted-foreground`,children:e.value}),e.required&&(0,F.jsx)(w,{variant:`outline`,className:`text-xs`,children:`Required`})]},e.name))})]}),e.requestBody&&(0,F.jsxs)(`div`,{className:`mb-4`,children:[(0,F.jsx)(`h4`,{className:`text-sm font-semibold mb-2`,children:`Request Body`}),(0,F.jsx)(z,{code:e.requestBody})]}),e.responseBody&&(0,F.jsxs)(`div`,{children:[(0,F.jsx)(`h4`,{className:`text-sm font-semibold mb-2`,children:`Response`}),(0,F.jsx)(z,{code:e.responseBody})]})]})]}),V=()=>(0,F.jsxs)(`div`,{className:`space-y-6`,children:[(0,F.jsx)(y,{children:(0,F.jsxs)(S,{children:[(0,F.jsxs)(x,{className:`flex items-center gap-2`,children:[(0,F.jsx)(_,{className:`h-5 w-5 text-primary`}),` API Authentication`]}),(0,F.jsxs)(C,{children:[`All Rentmaikar API requests must be authenticated with an API key. Keys are issued and rotated from `,(0,F.jsx)(`strong`,{children:`Admin → ERP → API Keys`}),`. Keys carry granular scopes and per-endpoint rate limits.`]})]})}),(0,F.jsxs)(y,{children:[(0,F.jsx)(S,{children:(0,F.jsx)(x,{className:`text-lg`,children:`Required & Recommended Headers`})}),(0,F.jsx)(b,{children:(0,F.jsx)(`div`,{className:`overflow-x-auto`,children:(0,F.jsxs)(`table`,{className:`w-full text-sm`,children:[(0,F.jsx)(`thead`,{children:(0,F.jsxs)(`tr`,{className:`border-b text-left`,children:[(0,F.jsx)(`th`,{className:`py-2 pr-4`,children:`Header`}),(0,F.jsx)(`th`,{className:`py-2 pr-4`,children:`Value`}),(0,F.jsx)(`th`,{className:`py-2 pr-4`,children:`Required`}),(0,F.jsx)(`th`,{className:`py-2`,children:`Notes`})]})}),(0,F.jsx)(`tbody`,{children:[{name:`Authorization`,value:`Bearer rmk_live_...`,required:!0,note:`Preferred. API key issued from Admin → ERP → API Keys.`},{name:`X-API-Key`,value:`rmk_live_...`,required:!1,note:`Alternative to Authorization header.`},{name:`Content-Type`,value:`application/json`,required:!0,note:`Required on POST / PUT / PATCH.`},{name:`Idempotency-Key`,value:`<uuid>`,required:!1,note:`Recommended for POST /payments and /rentals to safely retry.`},{name:`X-Rentmaikar-Region`,value:`US | NG`,required:!1,note:`Overrides region auto-detection for regional routing.`}].map(e=>(0,F.jsxs)(`tr`,{className:`border-b last:border-0`,children:[(0,F.jsx)(`td`,{className:`py-2 pr-4`,children:(0,F.jsx)(`code`,{className:`bg-muted px-2 py-0.5 rounded`,children:e.name})}),(0,F.jsx)(`td`,{className:`py-2 pr-4`,children:(0,F.jsx)(`code`,{className:`text-xs`,children:e.value})}),(0,F.jsx)(`td`,{className:`py-2 pr-4`,children:e.required?(0,F.jsx)(w,{children:`Required`}):(0,F.jsx)(w,{variant:`outline`,children:`Optional`})}),(0,F.jsx)(`td`,{className:`py-2 text-muted-foreground`,children:e.note})]},e.name))})]})})})]}),(0,F.jsxs)(y,{children:[(0,F.jsxs)(S,{children:[(0,F.jsx)(x,{className:`text-lg`,children:`Authentication Flows`}),(0,F.jsx)(C,{children:`Copy-paste examples for the most common calls.`})]}),(0,F.jsx)(b,{children:(0,F.jsxs)(O,{defaultValue:`curl`,children:[(0,F.jsxs)(D,{children:[(0,F.jsx)(T,{value:`curl`,children:`cURL`}),(0,F.jsx)(T,{value:`js`,children:`JavaScript`}),(0,F.jsx)(T,{value:`py`,children:`Python`})]}),(0,F.jsxs)(E,{value:`curl`,className:`space-y-3`,children:[(0,F.jsx)(`p`,{className:`text-sm text-muted-foreground`,children:`Authenticated request:`}),(0,F.jsx)(z,{code:`curl https://staging.rentmaikar.com/v1/vehicles \\
  -H "Authorization: Bearer rmk_live_your_key_here" \\
  -H "Content-Type: application/json"`}),(0,F.jsx)(`p`,{className:`text-sm text-muted-foreground`,children:`Rotate an API key (admin scope required):`}),(0,F.jsx)(z,{code:`curl -X POST https://staging.rentmaikar.com/v1/keys/KEY_ID/rotate \\
  -H "Authorization: Bearer rmk_live_admin_key"`})]}),(0,F.jsx)(E,{value:`js`,className:`space-y-3`,children:(0,F.jsx)(z,{code:`const res = await fetch("https://staging.rentmaikar.com/v1/rentals", {
  method: "POST",
  headers: {
    Authorization: \`Bearer \${process.env.RENTMAIKAR_API_KEY}\`,
    "Content-Type": "application/json",
    "Idempotency-Key": crypto.randomUUID(),
  },
  body: JSON.stringify({ vehicle_id: "veh_123", days: 7 }),
});

if (res.status === 401) throw new Error("Invalid or revoked API key");
if (res.status === 403) throw new Error("Key missing required scope");
if (res.status === 429) {
  const retry = res.headers.get("Retry-After");
  console.warn(\`Rate limited. Retry after \${retry}s\`);
}
const data = await res.json();`})}),(0,F.jsx)(E,{value:`py`,className:`space-y-3`,children:(0,F.jsx)(z,{code:`import os, uuid, requests

r = requests.post(
  "https://staging.rentmaikar.com/v1/payments/charge",
  headers={
    "Authorization": f"Bearer {os.environ['RENTMAIKAR_API_KEY']}",
    "Content-Type": "application/json",
    "Idempotency-Key": str(uuid.uuid4()),
  },
  json={"rental_id": "rnt_123", "amount": 15000, "currency": "NGN"},
  timeout=10,
)

if r.status_code == 429:
  print("Rate limited, retry after:", r.headers.get("Retry-After"))
r.raise_for_status()
print(r.json())`})})]})})]}),(0,F.jsxs)(y,{children:[(0,F.jsxs)(S,{children:[(0,F.jsxs)(x,{className:`text-lg flex items-center gap-2`,children:[(0,F.jsx)(h,{className:`h-5 w-5 text-primary`}),` Rate Limits per Endpoint`]}),(0,F.jsxs)(C,{children:[`Every response includes `,(0,F.jsx)(`code`,{children:`X-RateLimit-Limit`}),`, `,(0,F.jsx)(`code`,{children:`X-RateLimit-Remaining`}),`, and `,(0,F.jsx)(`code`,{children:`X-RateLimit-Reset`}),`. Exceeding a limit returns HTTP `,(0,F.jsx)(`code`,{children:`429`}),` with a`,(0,F.jsx)(`code`,{children:` Retry-After`}),` header (seconds).`]})]}),(0,F.jsx)(b,{children:(0,F.jsx)(`div`,{className:`overflow-x-auto`,children:(0,F.jsxs)(`table`,{className:`w-full text-sm`,children:[(0,F.jsx)(`thead`,{children:(0,F.jsxs)(`tr`,{className:`border-b text-left`,children:[(0,F.jsx)(`th`,{className:`py-2 pr-4`,children:`Method`}),(0,F.jsx)(`th`,{className:`py-2 pr-4`,children:`Path`}),(0,F.jsx)(`th`,{className:`py-2 pr-4`,children:`Sustained Limit`}),(0,F.jsx)(`th`,{className:`py-2 pr-4`,children:`Burst`}),(0,F.jsx)(`th`,{className:`py-2`,children:`Required Scopes`})]})}),(0,F.jsx)(`tbody`,{children:[{method:`GET`,path:`/v1/vehicles`,limit:`120 / min`,burst:`30`,scope:`read + vehicles`},{method:`POST`,path:`/v1/vehicles`,limit:`30 / min`,burst:`10`,scope:`write + vehicles`},{method:`GET`,path:`/v1/rentals`,limit:`120 / min`,burst:`30`,scope:`read`},{method:`POST`,path:`/v1/rentals`,limit:`30 / min`,burst:`5`,scope:`write`},{method:`GET`,path:`/v1/payments`,limit:`60 / min`,burst:`15`,scope:`read + payments`},{method:`POST`,path:`/v1/payments/charge`,limit:`20 / min`,burst:`3`,scope:`write + payments`},{method:`GET`,path:`/v1/users/{id}`,limit:`60 / min`,burst:`10`,scope:`read + users`},{method:`POST`,path:`/v1/notifications/send`,limit:`30 / min`,burst:`5`,scope:`write`},{method:`POST`,path:`/v1/keys/{id}/rotate`,limit:`5 / min`,burst:`1`,scope:`admin`}].map(e=>(0,F.jsxs)(`tr`,{className:`border-b last:border-0`,children:[(0,F.jsx)(`td`,{className:`py-2 pr-4`,children:(0,F.jsx)(w,{className:`${R[e.method]} font-mono text-xs`,children:e.method})}),(0,F.jsx)(`td`,{className:`py-2 pr-4`,children:(0,F.jsx)(`code`,{children:e.path})}),(0,F.jsx)(`td`,{className:`py-2 pr-4`,children:e.limit}),(0,F.jsx)(`td`,{className:`py-2 pr-4`,children:e.burst}),(0,F.jsx)(`td`,{className:`py-2 text-muted-foreground`,children:e.scope})]},`${e.method}-${e.path}`))})]})})})]}),(0,F.jsxs)(y,{children:[(0,F.jsxs)(S,{children:[(0,F.jsx)(x,{className:`text-lg`,children:`API Key Scopes`}),(0,F.jsx)(C,{children:`Assign only the scopes the integration needs.`})]}),(0,F.jsx)(b,{children:(0,F.jsx)(`div`,{className:`grid gap-2 md:grid-cols-2`,children:[{scope:`read`,desc:`Read any resource returned by GET endpoints.`},{scope:`write`,desc:`Create and update resources via POST / PATCH.`},{scope:`delete`,desc:`Delete resources via DELETE.`},{scope:`vehicles`,desc:`Access /v1/vehicles endpoints.`},{scope:`users`,desc:`Access /v1/users endpoints.`},{scope:`payments`,desc:`Access /v1/payments endpoints.`}].map(e=>(0,F.jsxs)(`div`,{className:`flex items-start gap-2 rounded-lg border p-3`,children:[(0,F.jsx)(m,{className:`h-4 w-4 mt-0.5 text-primary`}),(0,F.jsxs)(`div`,{children:[(0,F.jsx)(`code`,{className:`text-sm font-semibold`,children:e.scope}),(0,F.jsx)(`p`,{className:`text-xs text-muted-foreground`,children:e.desc})]})]},e.scope))})})]}),(0,F.jsxs)(y,{children:[(0,F.jsx)(S,{children:(0,F.jsxs)(x,{className:`text-lg flex items-center gap-2`,children:[(0,F.jsx)(v,{className:`h-5 w-5 text-destructive`}),` Error Response Schema`]})}),(0,F.jsxs)(b,{className:`space-y-3`,children:[(0,F.jsx)(z,{code:`{
  "error": {
    "code": "insufficient_scope",
    "message": "This API key does not have the 'payments' scope.",
    "request_id": "req_01HABC..."
  }
}`}),(0,F.jsxs)(`div`,{className:`grid gap-2 text-sm`,children:[(0,F.jsxs)(`div`,{children:[(0,F.jsx)(w,{variant:`outline`,children:`401`}),` `,(0,F.jsx)(`code`,{children:`invalid_key`}),` — key missing, revoked, or expired.`]}),(0,F.jsxs)(`div`,{children:[(0,F.jsx)(w,{variant:`outline`,children:`403`}),` `,(0,F.jsx)(`code`,{children:`insufficient_scope`}),` — key lacks the required scope.`]}),(0,F.jsxs)(`div`,{children:[(0,F.jsx)(w,{variant:`outline`,children:`429`}),` `,(0,F.jsx)(`code`,{children:`rate_limited`}),` — retry after the `,(0,F.jsx)(`code`,{children:`Retry-After`}),` value.`]}),(0,F.jsxs)(`div`,{children:[(0,F.jsx)(w,{variant:`outline`,children:`5xx`}),` `,(0,F.jsx)(`code`,{children:`upstream_error`}),` — transient; retry with exponential backoff.`]})]})]})]})]}),H=()=>{let[e,t]=(0,P.useState)(`all`),r=e===`all`?I:I.filter(t=>t.category===e);return(0,F.jsxs)(`div`,{className:`min-h-screen bg-background`,children:[(0,F.jsx)(c,{}),(0,F.jsxs)(`main`,{className:`container mx-auto px-4 py-8 max-w-6xl`,children:[(0,F.jsxs)(`div`,{className:`text-center mb-12`,children:[(0,F.jsxs)(w,{className:`mb-4`,variant:`secondary`,children:[(0,F.jsx)(l,{className:`h-3 w-3 mr-1`}),`Developer Documentation`]}),(0,F.jsx)(`h1`,{className:`text-4xl font-bold mb-4`,children:`Rentmaikar API Reference`}),(0,F.jsx)(`p`,{className:`text-xl text-muted-foreground max-w-2xl mx-auto`,children:`Integrate with Rentmaikar's platform using our REST API endpoints. Build powerful integrations for vehicle management, notifications, and payments.`})]}),(0,F.jsxs)(`div`,{className:`grid md:grid-cols-3 gap-4 mb-12`,children:[(0,F.jsxs)(y,{children:[(0,F.jsx)(S,{className:`pb-3`,children:(0,F.jsxs)(x,{className:`flex items-center gap-2 text-lg`,children:[(0,F.jsx)(_,{className:`h-5 w-5 text-primary`}),`Authentication`]})}),(0,F.jsxs)(b,{children:[(0,F.jsx)(`p`,{className:`text-sm text-muted-foreground mb-3`,children:`All API requests require authentication using your service role key.`}),(0,F.jsx)(z,{code:`Authorization: Bearer <service_role_key>`})]})]}),(0,F.jsxs)(y,{children:[(0,F.jsx)(S,{className:`pb-3`,children:(0,F.jsxs)(x,{className:`flex items-center gap-2 text-lg`,children:[(0,F.jsx)(h,{className:`h-5 w-5 text-primary`}),`Base URL`]})}),(0,F.jsxs)(b,{children:[(0,F.jsx)(`p`,{className:`text-sm text-muted-foreground mb-3`,children:`All endpoints are relative to the Supabase functions URL.`}),(0,F.jsx)(z,{code:`https://<project-id>.supabase.co`})]})]}),(0,F.jsxs)(y,{children:[(0,F.jsx)(S,{className:`pb-3`,children:(0,F.jsxs)(x,{className:`flex items-center gap-2 text-lg`,children:[(0,F.jsx)(v,{className:`h-5 w-5 text-primary`}),`Rate Limits`]})}),(0,F.jsxs)(b,{children:[(0,F.jsx)(`p`,{className:`text-sm text-muted-foreground mb-3`,children:`API requests are rate-limited to ensure fair usage.`}),(0,F.jsx)(`div`,{className:`text-sm`,children:(0,F.jsx)(`span`,{className:`font-mono bg-muted px-2 py-0.5 rounded`,children:`1000 req/min`})})]})]})]}),(0,F.jsxs)(O,{defaultValue:`authentication`,className:`space-y-6`,children:[(0,F.jsxs)(D,{className:`grid w-full grid-cols-4`,children:[(0,F.jsx)(T,{value:`authentication`,children:`Authentication`}),(0,F.jsx)(T,{value:`endpoints`,children:`Endpoints`}),(0,F.jsx)(T,{value:`webhooks`,children:`Webhooks`}),(0,F.jsx)(T,{value:`sdks`,children:`SDKs & Tools`})]}),(0,F.jsx)(E,{value:`authentication`,className:`space-y-6`,children:(0,F.jsx)(V,{})}),(0,F.jsxs)(E,{value:`endpoints`,className:`space-y-6`,children:[(0,F.jsx)(`div`,{className:`flex flex-wrap gap-2`,children:L.map(r=>{let i=r.icon;return(0,F.jsxs)(n,{variant:e===r.id?`default`:`outline`,size:`sm`,onClick:()=>t(r.id),className:`gap-2`,children:[(0,F.jsx)(i,{className:`h-4 w-4`}),r.label]},r.id)})}),(0,F.jsx)(k,{className:`h-[600px] pr-4`,children:(0,F.jsx)(N,{type:`single`,collapsible:!0,className:`space-y-2`,children:r.map(e=>(0,F.jsx)(B,{endpoint:e},e.path))})})]}),(0,F.jsxs)(E,{value:`webhooks`,className:`space-y-6`,children:[(0,F.jsxs)(y,{className:`border-primary/30 bg-primary/5`,children:[(0,F.jsxs)(S,{children:[(0,F.jsxs)(x,{className:`flex items-center gap-2`,children:[(0,F.jsx)(m,{className:`h-5 w-5 text-primary`}),`Communication Provider Secrets`]}),(0,F.jsx)(C,{children:`Required secrets for region-aware SMS/Voice routing. Configure these in Lovable Cloud → Secrets.`})]}),(0,F.jsxs)(b,{className:`space-y-4`,children:[(0,F.jsxs)(`div`,{children:[(0,F.jsx)(`h4`,{className:`font-semibold text-sm mb-2`,children:`🇺🇸 Twilio (USA — +1)`}),(0,F.jsxs)(`div`,{className:`space-y-1 text-sm`,children:[(0,F.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,F.jsx)(`code`,{className:`bg-muted px-2 py-0.5 rounded`,children:`TWILIO_ACCOUNT_SID`}),(0,F.jsx)(`span`,{className:`text-muted-foreground`,children:`— Account SID from Twilio Console`})]}),(0,F.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,F.jsx)(`code`,{className:`bg-muted px-2 py-0.5 rounded`,children:`TWILIO_AUTH_TOKEN`}),(0,F.jsx)(`span`,{className:`text-muted-foreground`,children:`— Auth Token from Twilio Console`})]}),(0,F.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,F.jsx)(`code`,{className:`bg-muted px-2 py-0.5 rounded`,children:`TWILIO_PHONE_NUMBER`}),(0,F.jsx)(`span`,{className:`text-muted-foreground`,children:`— Platform phone number for US SMS/Voice`})]})]})]}),(0,F.jsxs)(`div`,{children:[(0,F.jsx)(`h4`,{className:`font-semibold text-sm mb-2`,children:`🇳🇬 Termii (Nigeria — +234)`}),(0,F.jsxs)(`div`,{className:`space-y-1 text-sm`,children:[(0,F.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,F.jsx)(`code`,{className:`bg-muted px-2 py-0.5 rounded`,children:`TERMII_API_KEY`}),(0,F.jsxs)(`span`,{className:`text-muted-foreground`,children:[`— API key from `,(0,F.jsx)(`a`,{href:`https://accounts.termii.com`,target:`_blank`,rel:`noopener noreferrer`,className:`underline text-primary`,children:`Termii Dashboard`}),` → Settings → API Keys`]})]}),(0,F.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,F.jsx)(`code`,{className:`bg-muted px-2 py-0.5 rounded`,children:`TERMII_SENDER_ID`}),(0,F.jsx)(`span`,{className:`text-muted-foreground`,children:`— Registered Sender ID (e.g. "RENTMAIKAR") from Termii → Sender IDs`})]})]})]}),(0,F.jsxs)(`div`,{className:`pt-2 border-t`,children:[(0,F.jsx)(`h4`,{className:`font-semibold text-sm mb-2`,children:`Provider Registry`}),(0,F.jsxs)(`p`,{className:`text-sm text-muted-foreground`,children:[`Region routing is configured via the `,(0,F.jsx)(`code`,{className:`bg-muted px-1 py-0.5 rounded`,children:`communication_providers`}),` table. Admins can update forwarding numbers, sender IDs, and toggle providers on/off from the Communication Settings panel.`]})]})]})]}),(0,F.jsxs)(y,{children:[(0,F.jsxs)(S,{children:[(0,F.jsx)(x,{children:`Webhook Events`}),(0,F.jsx)(C,{children:`Subscribe to real-time events from the Rentmaikar platform`})]}),(0,F.jsxs)(b,{className:`space-y-4`,children:[(0,F.jsx)(`div`,{className:`grid gap-4`,children:[{event:`incident.created`,description:`Fired when a new incident is reported`},{event:`incident.resolved`,description:`Fired when an incident is marked as resolved`},{event:`payment.default`,description:`Fired when a payment default is detected`},{event:`device.activated`,description:`Fired when an IoT device comes online`},{event:`vehicle.command`,description:`Fired when a remote command is sent to a vehicle`},{event:`user.approved`,description:`Fired when a user account is approved`}].map(e=>(0,F.jsxs)(`div`,{className:`flex items-start justify-between p-3 border rounded-lg`,children:[(0,F.jsxs)(`div`,{children:[(0,F.jsx)(`code`,{className:`text-sm font-medium`,children:e.event}),(0,F.jsx)(`p`,{className:`text-sm text-muted-foreground mt-1`,children:e.description})]}),(0,F.jsx)(w,{variant:`outline`,children:`Coming Soon`})]},e.event))}),(0,F.jsxs)(`div`,{className:`mt-6`,children:[(0,F.jsx)(`h4`,{className:`font-semibold mb-3`,children:`Webhook Payload Example`}),(0,F.jsx)(z,{code:`{
  "event": "incident.created",
  "timestamp": "2024-01-15T10:30:00Z",
  "data": {
    "id": "uuid",
    "type": "accident",
    "severity": "high",
    "vehicleId": "uuid",
    "driverId": "uuid"
  },
  "signature": "sha256=..."
}`})]})]})]})]}),(0,F.jsx)(E,{value:`sdks`,className:`space-y-6`,children:(0,F.jsxs)(`div`,{className:`grid md:grid-cols-2 gap-6`,children:[(0,F.jsxs)(y,{children:[(0,F.jsxs)(S,{children:[(0,F.jsx)(x,{children:`JavaScript/TypeScript SDK`}),(0,F.jsx)(C,{children:`Official SDK for web and Node.js applications`})]}),(0,F.jsxs)(b,{children:[(0,F.jsx)(z,{code:`npm install @rentmaikar/sdk

import { RentmaikarClient } from '@rentmaikar/sdk';

const client = new RentmaikarClient({
  apiKey: process.env.RENTMAIKAR_API_KEY
});

// Send notification
await client.notifications.send({
  type: 'sms',
  to: '+1234567890',
  message: 'Your vehicle is ready'
});`}),(0,F.jsx)(w,{variant:`outline`,className:`mt-4`,children:`Coming Soon`})]})]}),(0,F.jsxs)(y,{children:[(0,F.jsxs)(S,{children:[(0,F.jsx)(x,{children:`Python SDK`}),(0,F.jsx)(C,{children:`Official SDK for Python applications`})]}),(0,F.jsxs)(b,{children:[(0,F.jsx)(z,{code:`pip install rentmaikar

from rentmaikar import Client

client = Client(api_key=os.environ['RENTMAIKAR_API_KEY'])

# Track vehicle
vehicle = client.vehicles.get('vehicle-id')
print(vehicle.location)`}),(0,F.jsx)(w,{variant:`outline`,className:`mt-4`,children:`Coming Soon`})]})]}),(0,F.jsxs)(y,{children:[(0,F.jsxs)(S,{children:[(0,F.jsx)(x,{children:`MQTT Integration`}),(0,F.jsx)(C,{children:`Real-time vehicle tracking via MQTT protocol`})]}),(0,F.jsxs)(b,{children:[(0,F.jsx)(z,{code:`// MQTT Topics
vehicles/{vehicleId}/location
vehicles/{vehicleId}/status
vehicles/{vehicleId}/sensors
vehicles/{vehicleId}/commands

// Subscribe to location updates
mqttClient.subscribe('vehicles/+/location');
mqttClient.on('message', (topic, payload) => {
  const data = JSON.parse(payload);
  console.log(data.lat, data.lng);
});`}),(0,F.jsx)(w,{className:`mt-4 bg-green-500/20 text-green-400`,children:`Available`})]})]}),(0,F.jsxs)(y,{children:[(0,F.jsxs)(S,{children:[(0,F.jsx)(x,{children:`Postman Collection`}),(0,F.jsx)(C,{children:`Ready-to-use API collection for testing`})]}),(0,F.jsxs)(b,{className:`space-y-4`,children:[(0,F.jsx)(`p`,{className:`text-sm text-muted-foreground`,children:`Download our Postman collection to quickly test all API endpoints with pre-configured requests and examples.`}),(0,F.jsx)(n,{variant:`outline`,className:`w-full`,disabled:!0,children:`Download Collection`}),(0,F.jsx)(w,{variant:`outline`,children:`Coming Soon`})]})]})]})})]}),(0,F.jsx)(y,{className:`mt-12`,children:(0,F.jsxs)(b,{className:`flex flex-col md:flex-row items-center justify-between p-6 gap-4`,children:[(0,F.jsxs)(`div`,{children:[(0,F.jsx)(`h3`,{className:`font-semibold text-lg`,children:`Need Help?`}),(0,F.jsx)(`p`,{className:`text-muted-foreground`,children:`Contact our developer support team for integration assistance.`})]}),(0,F.jsxs)(`div`,{className:`flex gap-3`,children:[(0,F.jsx)(n,{variant:`outline`,children:`View Changelog`}),(0,F.jsx)(n,{children:`Contact Support`})]})]})})]}),(0,F.jsx)(a,{})]})};export{H as default};